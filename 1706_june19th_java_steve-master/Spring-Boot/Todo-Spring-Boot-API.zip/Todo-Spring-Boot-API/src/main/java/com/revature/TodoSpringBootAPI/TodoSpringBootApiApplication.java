package com.revature.TodoSpringBootAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodoSpringBootApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(TodoSpringBootApiApplication.class, args);
	}
}
